<template>
  <div>
    <el-card style="width: 40%; margin: 10px">
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item style="text-align: center" label-width="0">
          <el-upload
              class="avatar-uploader"
              action="http://localhost:8888/files/upload"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
          >
            <img v-if="form.avatar" :src="form.avatar" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="用户名">
          <el-input v-model="form.userName" disabled></el-input>
        </el-form-item>

        <el-form-item label="年龄">
          <el-input v-model="form.age"></el-input>
        </el-form-item>
        <el-form-item label="性别">
          <el-input v-model="form.gender"></el-input>
        </el-form-item>
<!--        <el-form-item label="专业">-->
<!--          <el-input v-model="form.major"></el-input>-->
<!--        </el-form-item>-->

        <el-form-item label="专业">
          <!--          <el-input v-model="form.major" style="width: 70%"></el-input>-->
          <el-select v-model="value"  @focus="getmajor">
            <el-option
                v-for="item in options"
                :key="item.majorId"
                :label="item.majorName"
                :value="item.majorName"
            >
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="密码">
          <el-input v-model="form.password" show-password></el-input>
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="form.email"></el-input>
        </el-form-item>
      </el-form>
      <div style="text-align: center">
        <el-button type="primary" @click="update">保存</el-button>
      </div>
    </el-card>

  </div>
</template>

<script>
import request from "@/utils/request";
import {ref} from "vue";

export default {
  name: "Person",
  data() {
    return {
      form: {}
    }
  },
  setup() {
    return {

      options: ref(''),
      value: ref('')
    }
  },
  created() {
    let str = sessionStorage.getItem("user") || "{}"
    this.form = JSON.parse(str)
    // 赋值专业信息
    this.value = JSON.parse(str).major
    // sessionStorage.setItem("user",JSON.parse(str))
  },
  methods: {
    handleAvatarSuccess(res) {
      this.form.avatar = res.data
      this.$message.success("上传成功")
      // this.update()
    },
    // 获取专业列表
    getmajor() {
      request.get("/major",{
        params: {
          pageSize: 50,
        }
      }).then(res=> {
        // 把专业信息赋值给select
        this.options = res.data.records
      })
    },


    update() {
      this.form.major = this.value
      request.put("/user", this.form).then(res => {
        console.log(res)
        if (res.code === '0') {
          this.$message({
            type: "success",
            message: "更新成功"
          })
          sessionStorage.setItem("user", JSON.stringify(this.form))
          // 触发Layout更新用户信息
          this.$emit("userInfo")
        } else {
          this.$message({
            type: "error",
            message: res.msg
          })
        }
      })
    }
  }
}
</script>

<style scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  line-height: 120px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>