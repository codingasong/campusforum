<template>
  <el-container>
    <!--    头部-->
<!--    <el-header style="line-height: 60px; border-bottom: 1px solid #cccccc; ">
      <Header :user="user"/>
    </el-header>-->
    <!--    主体-->
    <el-container>
      <!--      侧边栏-->
      <el-aside style="width: 20%;">
        <el-row>
          <el-col :span="8"></el-col>
          <el-col :span="16"> <AsideFront/></el-col>

        </el-row>

      </el-aside>
      <!--      内容-->
      <el-main>
        <router-view style="flex: 1" />
        <!--        @userInfo="refreshUser"-->
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Header from "@/components/Header";
import AsideFront from "@/components/AsideFront";

export default {
  name: "Layoutq",
  components: {
    AsideFront,
    Header,

  },
}
</script>

<style scoped>

</style>