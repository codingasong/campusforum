<template>
  <el-container>
    <router-view/>
  </el-container>

</template>

<script>


export default {
  name: "App",
}

</script>


<style>

</style>
