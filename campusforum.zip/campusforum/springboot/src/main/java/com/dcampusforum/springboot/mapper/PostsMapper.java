package com.dcampusforum.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dcampusforum.springboot.entity.Posts;

public interface PostsMapper extends BaseMapper<Posts> {
}
