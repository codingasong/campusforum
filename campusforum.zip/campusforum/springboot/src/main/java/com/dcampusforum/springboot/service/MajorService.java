package com.dcampusforum.springboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dcampusforum.springboot.entity.Major;
import com.dcampusforum.springboot.mapper.MajorMapper;

public interface MajorService extends IService<Major> {
}
