package com.dcampusforum.springboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dcampusforum.springboot.entity.Posts;

public interface PostsService extends IService<Posts> {
}
