package com.dcampusforum.springboot.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dcampusforum.springboot.entity.User;


public interface UserService extends IService<User> {

//    Page<User> findPage(Page<Object> objectPage, String search);
//    Page<User> findGoodsPage(Page<Object> objectPage, String search);
}
