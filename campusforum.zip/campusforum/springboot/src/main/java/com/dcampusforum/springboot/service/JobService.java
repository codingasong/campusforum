package com.dcampusforum.springboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dcampusforum.springboot.entity.Job;

public interface JobService extends IService<Job> {
}
