package com.dcampusforum.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dcampusforum.springboot.entity.Job;

public interface JobMapper extends BaseMapper<Job> {
}
